# SATP Core

Secure memory management for LLMs.
